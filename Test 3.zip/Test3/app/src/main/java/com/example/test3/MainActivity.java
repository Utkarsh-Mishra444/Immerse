package com.example.test3;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import com.atilika.kuromoji.ipadic.Token;
import com.atilika.kuromoji.ipadic.Tokenizer;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        ImageButton searchIcon = findViewById(R.id.searchIcon);
        EditText searchBar = findViewById(R.id.searchBar);
        searchIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputText = searchBar.getText().toString();
                if (!inputText.isEmpty()) {
                    tokenizeInput(inputText);
                } else {
                    Toast.makeText(MainActivity.this, "Please enter some text to tokenize.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private void tokenizeInput(String text) {
        Tokenizer tokenizer = new Tokenizer() ;
        StringBuilder result = new StringBuilder();
        for (Token token : tokenizer.tokenize(text)) {
            result.append(token.getSurface()).append("\t").append(token.getAllFeatures()).append("\n");
        }
        Toast.makeText(this, result.toString(), Toast.LENGTH_LONG).show();
    }
}
